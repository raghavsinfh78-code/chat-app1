const socket = io();

const form = document.getElementById("form");
const input = document.getElementById("input");
const messages = document.getElementById("messages");

const headerName = document.getElementById("header-name");
const headerStatus = document.getElementById("header-status");
const headerAvatar = document.getElementById("header-avatar");

// --- Login prompt ---
let username = prompt("Enter your name:") || "Anonymous";
headerName.textContent = username;
headerStatus.textContent = "Online";

// Give the header avatar a stable image (client-side) until server responds
headerAvatar.src = `https://i.pravatar.cc/40?u=${username}-${Math.random().toString(36).slice(2,7)}`;

// Tell server who we are
socket.emit("set username", username);

// --- Send message ---
form.addEventListener("submit", (e) => {
  e.preventDefault();
  const text = (input.value || "").trim();
  if (!text) return;
  socket.emit("chat message", text);
  input.value = "";
});

// --- Render incoming messages ---
socket.on("chat message", (msg) => {
  // msg = { id, user, avatar, text }
  const isMe = msg.id === socket.id;

  const li = document.createElement("li");
  li.className = `message ${isMe ? "me" : "other"}`;

  const avatar = document.createElement("img");
  avatar.className = "avatar";
  avatar.src = msg.avatar;

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = msg.text;

  if (isMe) {
    li.appendChild(bubble);
    li.appendChild(avatar);
  } else {
    li.appendChild(avatar);
    li.appendChild(bubble);
  }

  messages.appendChild(li);
  messages.scrollTop = messages.scrollHeight;

  // Update our own header avatar once we receive our first message (ensures server avatar)
  if (isMe && headerAvatar && headerAvatar.dataset.locked !== "1") {
    headerAvatar.src = msg.avatar;
    headerAvatar.dataset.locked = "1";
  }
});
