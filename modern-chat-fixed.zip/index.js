const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, "public")));

// --- Socket.IO ---
io.on("connection", (socket) => {
  // Set username from client
  socket.on("set username", (username) => {
    // username might be object or string depending on client; normalize
    if (typeof username === "object" && username !== null) {
      socket.username = username.username || "Anonymous";
    } else {
      socket.username = username || "Anonymous";
    }
    // stable avatar per socket connection
    socket.avatar = `https://i.pravatar.cc/48?u=${socket.id}`;
  });

  // Chat message can come as string or object; normalize to {text}
  socket.on("chat message", (payload) => {
    const text = typeof payload === "string" ? payload : (payload && payload.text) || "";
    if (!text) return;
    io.emit("chat message", {
      id: socket.id,
      user: socket.username || "Anonymous",
      avatar: socket.avatar || `https://i.pravatar.cc/48?u=${socket.id}`,
      text
    });
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
});
